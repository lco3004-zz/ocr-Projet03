# Projet : ocr-Projet03 (OpenClassRooms)
 ## refactor selon :
 -  https://openclassrooms.com/forum/sujet/conventions-de-codage-en-java-64171
 ## Remise à zéro pour refactoring
 - Branche source : dev/addMaven
 
 

 
