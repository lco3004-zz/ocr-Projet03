package fr.ocr.mastermind;

import java.util.ArrayList;

public interface ValidationPropale {
    Boolean apply(ArrayList<Character> proposition, ArrayList<Character> secret);
}
