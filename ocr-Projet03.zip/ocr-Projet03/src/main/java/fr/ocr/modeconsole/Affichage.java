package fr.ocr.modeconsole;

public interface Affichage {
    void Display();
}
